import React from 'react';
import styles from './CourseWeek.module.css';

const CourseWeek: React.FC<{ weekNumber: number }> = ({ weekNumber }) => (
  <div className={styles.weekContainer}>
    <div className={styles.description}>
      <h3 className={styles.title}>Tuần {weekNumber}</h3>
      <p>Mô tả tuần học...</p>
    </div>
    <div className={styles.lesson}>
      <p>Nội dung bài học...</p>
    </div>
    <div className={styles.statistics}>
      <p>Thống kê tuần học...</p>
    </div>
  </div>
);

export default CourseWeek;