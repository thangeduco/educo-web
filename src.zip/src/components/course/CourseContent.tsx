import React from 'react';
import { useLocation } from 'react-router-dom';
import CourseHeader from './CourseHeader';
import CourseWeek from './CourseWeek';
import styles from './CourseContent.module.css';

const CourseContent: React.FC<{ courseId: string }> = ({ courseId }) => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);

  const grade = queryParams.get('grade') || '';
  const type = queryParams.get('type') || '';
  const subType = queryParams.get('subType') || '';

  const startDate = '11/05/2025';
  const endDate = '11/12/2025'
  const completedCount = 20;
  const totalCount = 100;
  const numOfWeek = 6;



  const title = `${grade} - ${subType} - ${type}`;
  const mockWeeks = [1, 2, 3];

  return (
    <div className={styles.wrapper}>
      <CourseHeader
        courseTitle={title}
        startDate={startDate}
        endDate={endDate}
        completedCount={completedCount}
        totalCount={totalCount}
        numOfWeek = {numOfWeek}
      />
      {mockWeeks.map((week) => (
        <CourseWeek key={week} weekNumber={week} />
      ))}
    </div>
  );
};

export default CourseContent;
