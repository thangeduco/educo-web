// src/pages/CoursePage.tsx
import React from 'react';
import { useParams } from 'react-router-dom';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import CourseContent from '../components/course/CourseContent';
import CoursePreview from '../components/course/CoursePreview';
import styles from './CoursePage.module.css';

const CoursePage = () => {
  const { id } = useParams();
  const isAuthenticated = localStorage.getItem('token') !== null;

  return (
    <div className={styles.pageContainer}>
      <Header fixed />
      <main className={styles.mainContent}>
        {isAuthenticated ? (
          <CourseContent courseId={id!} />
        ) : (
          <CoursePreview courseId={id!} />
        )}
      </main>
      <Footer />
    </div>
  );
};

export default CoursePage;
