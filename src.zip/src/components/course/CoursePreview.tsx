// src/components/course/CoursePreview.tsx
import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import styles from './CoursePreview.module.css';

interface CoursePreviewProps {
  courseId: string;
}

const CoursePreview: React.FC<CoursePreviewProps> = ({ courseId }) => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleContinue = () => {
    navigate(`/course/${courseId}${location.search}`);
  };

  return (
    <div className={styles.container}>
      <div className={styles.main}>
        <div className={styles.imageSection}>
          <img
            src={require('../../assets/images/BasicMathProcess.png')}
            alt="Lộ trình học tốt toán trên lớp"
            className={styles.previewImage}
          />
        </div>

        <div className={styles.descriptionSection}>
          <h2>Giới thiệu khóa học: {courseId}</h2>
          <p>
            Mỗi tuần học trong chuyên mục học toán hàng tuần trên mathx.vn đều bao gồm:
            <br />1. Bài giảng lý thuyết cơ bản theo chương trình sách giáo khoa, nội dung kiến thức ứng với tuần đang học.
            <br />2. Đề luyện tập cơ bản và nâng cao: gồm các bài tập luyện tập cơ bản bám sát kiến thức sách giáo khoa và đề toán nâng cao - toán tư duy.
            <br />3. Bài giảng toán tư duy hàng tuần: gồm các bài toán nâng cao, phát triển tư duy của học sinh.
          </p>

          <button className={styles.continueButton} onClick={handleContinue}>
            Tiếp tục học
          </button>
        </div>
      </div>
    </div>
  );
};

export default CoursePreview;
